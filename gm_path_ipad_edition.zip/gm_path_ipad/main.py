import io, os, shutil
from pathlib import Path
import chess, chess.engine, chess.pgn
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE=Path(__file__).parent
app=FastAPI(title="GM-Path iPad Chess Trainer")
app.mount("/static", StaticFiles(directory=BASE/"static"), name="static")

def engine_path():
    for p in [os.getenv("STOCKFISH_PATH"), shutil.which("stockfish"), "/usr/games/stockfish", "/usr/bin/stockfish"]:
        if p and Path(p).is_file(): return p
    return None

@app.get("/")
def home(): return FileResponse(BASE/"static"/"index.html")

@app.get("/api/health")
def health(): return {"ok":True,"stockfish_available":bool(engine_path())}

class Request(BaseModel):
    pgn:str=Field(min_length=5,max_length=200000)
    depth:int=Field(default=12,ge=8,le=20)

@app.post("/api/analyze")
def analyze(req:Request):
    path=engine_path()
    if not path: raise HTTPException(503,"Stockfish ist auf dem Server nicht installiert.")
    game=chess.pgn.read_game(io.StringIO(req.pgn))
    if game is None: raise HTTPException(400,"Keine gültige PGN-Partie gefunden.")
    try: engine=chess.engine.SimpleEngine.popen_uci(path)
    except Exception as e: raise HTTPException(503,f"Stockfish-Start fehlgeschlagen: {e}")
    board=game.board(); rows=[]
    try:
        for ply,move in enumerate(game.mainline_moves(),1):
            side=board.turn
            before=engine.analyse(board,chess.engine.Limit(depth=req.depth))
            best=before.get("pv",[None])[0]
            score1=before.get("score")
            cp1=score1.pov(chess.WHITE).score(mate_score=100000) if score1 else None
            san=board.san(move); board.push(move)
            after=engine.analyse(board,chess.engine.Limit(depth=req.depth))
            score2=after.get("score")
            cp2=score2.pov(chess.WHITE).score(mate_score=100000) if score2 else None
            loss=None if cp1 is None or cp2 is None else max(0,cp1-cp2) if side==chess.WHITE else max(0,cp2-cp1)
            prev=board.copy(); prev.pop()
            try: best_san=prev.san(best) if best else "—"
            except Exception: best_san=best.uci() if best else "—"
            rows.append({"ply":ply,"side":"Weiß" if side else "Schwarz","move":san,"best":best_san,"loss_cp":loss})
    finally: engine.quit()
    return {"white":game.headers.get("White","?"),"black":game.headers.get("Black","?"),"result":game.headers.get("Result","*"),"depth":req.depth,"rows":rows}
