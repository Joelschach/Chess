# GM-Path iPad Edition

Touch-optimierte Safari-Web-App mit Stockfish-Analyse auf dem Server.

## Lokal / eigener Server starten
Python 3.10+ und Stockfish erforderlich:
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
Dann auf dem iPad Safari öffnen: `http://SERVER-IP:8000`.

## Docker (Stockfish wird mitinstalliert)
```bash
docker build -t gm-path .
docker run --rm -p 8000:8000 gm-path
```

Für Zugriff außerhalb des eigenen WLANs auf einem öffentlich erreichbaren Server deployen und HTTPS aktivieren. In Safari kann die Website über Teilen → Zum Home-Bildschirm wie eine App abgelegt werden.

## Enthalten
- Touch-Schachbrett, legale Züge, Zugliste, Rücknahme und Brett drehen
- Taktik-, Endspiel-, Eröffnungs- und Mittelspiel-Trainingsnotizen
- Fortschrittsanzeige im Browser (localStorage)
- PGN-Upload und Stockfish-Analyse über FastAPI
- Dockerfile mit Stockfish

## Wichtige Grenzen vor öffentlichem Einsatz
Noch keine Benutzerkonten, Datenbank, Cloud-Synchronisierung oder Zugriffsschutz für die Analyse-API. Für öffentlichen Betrieb Authentifizierung, Rate-Limits und Upload-Limits ergänzen. Die Trainingsdaten bleiben im lokalen Browser; Browserdaten löschen kann sie entfernen. chess.js wird vom CDN geladen und benötigt beim Laden Internet.
